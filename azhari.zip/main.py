html_content = '''
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>repl.it</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <script>
      alert("hallo selamat pagi cantik");
      alert("jangan marah lagi ya cantik");
      alert("cuma mau bilang sayang itu cantik bahagia ada kamu jadi jangan insecure makan teratur jangan  sering marah marah");
      alert("semangat ya sayang");
      alert("jangan lupa bahagia cantik");
      alert("loveyou");
    </script>
  </head>
  <body>
    <script src="script.js"></script>
  </body>
</html>
'''

with open('index.html', 'w') as file:
  file.write(html_content)

print("File HTML berhasil dibuat dengan nama 'index.html'")
